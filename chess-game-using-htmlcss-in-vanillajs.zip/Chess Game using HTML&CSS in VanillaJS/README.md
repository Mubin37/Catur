# JsChess
Implementation of chess game in a vanilla JS enviroment.

## Chess Computer Engine

- so far the chess "engine" just picks a random possible move
- to be improved

## To be implemented
- underpromotion
